//Ali Kaan Durany?ld?z H. Atacan Demir
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class PokerTester {
  
  static Hand hand = new Hand();
  static CardComponent card1 = new CardComponent(hand);
  static JButton button = new JButton("Repick Selected");
  static JButton button1 = new JButton("Go With This Hand");
  static JButton button2 = new JButton("Exit Game");
  static JButton button3 = new JButton("New Hand");
  static boolean buttonActivate = true;
  public static void main(String[] args) {
    
    JFrame frame = new JFrame("Poker Tester");
    frame.setSize(600, 400);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setLocationRelativeTo(null);
    frame.setResizable(false);
    
    JPanel p = new JPanel();
    p.add(button2);
    p.add(button);
    p.add(button1);
    p.add(button3);
    
    button.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
        if(buttonActivate){
          for(int i = 0; i < card1.getSelected().size(); i++) {
            System.out.println("Repicking card number: " + card1.getSelected().get(i));
          }
          hand.displayHand();
          hand.askForChange(card1.getSelected());
          System.out.println("Your new Hand: ");
          
          System.out.println(new Evaluator(hand,hand.bet).scoring());
          buttonActivate = false;
        }}
    });
    button1.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
        if(buttonActivate){
          System.out.println("Going With This Hand: ");
          
          System.out.println("Your new Hand: ");
          
          System.out.println(new Evaluator(hand,hand.bet).scoring());
          
          buttonActivate = false;
        }}
    });
    button2.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
        
        System.out.println("Exit: ");
        System.exit(0);
      }
    });
    button3.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
        if(buttonActivate){
          
          System.out.println("Your Hand: ");
          
          buttonActivate = false;
        }}
    });
    
    
    frame.getContentPane().add(p, BorderLayout.SOUTH);
    frame.add(card1);
    
    frame.setVisible(true);
  }
}


