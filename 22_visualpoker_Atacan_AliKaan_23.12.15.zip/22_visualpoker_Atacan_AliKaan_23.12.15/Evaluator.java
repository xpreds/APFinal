//Ali Kaan Durany?ld?z
public class Evaluator {
  int[] kind = new int[6];
  int[] val = new int[6];
  int payout = 0;
  int a ;
  Hand hand;
  //Constructs the Evaluator object and initialise instant field variables
  public Evaluator(Hand h,int a) {
    hand = h;
    this.a=a;
    valueKind();
    sort();
  }
  //Defines the value and the suit of the cards for further processing
  public void valueKind() {
    for(int i = 1; i <= 5; i++) {
      kind[i] = ((hand.hand[i]-1) / 13) + 1;
      val[i] = (hand.hand[i]-1) % 13;
      if(val[i] == 0) {
        val[i] = 13;
      }
    }
  }
  //Sorts the deck in ascending order for further processing
  public void sort() {
    for(int i = 1; i <= 5; i++) {
      for(int j = 1; j <= 5; j++) {
        if(val[i] > val[j]) {
          int sval = val[i];
          int skin = kind[i];
          
          kind[i] = kind[j];
          kind[j] = skin;
          val[i] = val[j];
          val[j] = sval;
          
        }
      }
      System.out.println("kind of "+i+" "+val[i-1]);
      System.out.println("suit of "+i+" "+kind[i-1]);
    }
    
  }
  
  public String scoring() {
    //Checks condition for Flush
    if(kind[1] == kind[2] && kind[2] == kind[3] && kind[3] == kind[4] && kind[4] == kind[5]) {
      if(val[1] == 13 && val[2] == 12 && val[3] == 11 && val[4] == 10 && val[5] == 1) {
        payout = 250;
        return "Flush Royale payout 250";
      }
      if(val[5] == val[4]+1 && val[4] == val[3]+1 && val[3] == val[2]+1 && val[2] == val[1]+1 || 
         val[5] == val[4]+1 && val[4] == val[3]+1 && val[3] == val[2]+1 && val[1] == 1) {
        payout = 50;
        return "Straight Flush payout 50";
      }
      payout = 5;
      return "Flush payout 5";
    }
    //Checks condition for Straight
    if(val[5] == val[4]+1 && val[4] == val[3]+1 && val[3] == val[2]+1 && val[2] == val[1]+1 || 
       val[5] == val[4]+1 && val[4] == val[3]+1 && val[3] == val[2]+1 && val[1] == 1)  {
      payout = 4;
      return "Straight payout 4";
    }
    //Checks condition for Four of a Kind
    if((val[1] == val[2] && val[2] == val[3] && val[3] == val[4]) ||
       (val[2] == val[3] && val[3] == val[4] && val[4] == val[5])) {
      payout = 25;
      return "Four of a Kind payout 25";
    }
    //Checks condition for Three of a Kind
    if((val[1] == val[2] && val[2] == val[3]) || 
       (val[2] == val[3] && val[3] == val[4]) ||
       (val[3] == val[4] && val[4] == val[5])) {
      payout = 3;
      return "Three of a Kind payout 3";
    }
    //Checks condition for Full House
    if((val[1] == val[2] && val[2] == val[3] && val[4] == val[5]) ||
       (val[1] == val[2] && val[3] == val[4] && val[4] == val[5])) {
      payout = 6;
      return "Full House payout 6";
    }
    //Checks condition for Two pairs
    if((val[1] == val[2] && val[3] == val[4]) ||
       (val[1] == val[2] && val[4] == val[5]) ||
       (val[2] == val[3] && val[4] == val[5])) {
      payout = 2;
      return "Two pairs payout 2";
    }
    //Checks condition for one pair
    if((val[1] == val[2]) || (val[2] == val[3]) ||
       (val[3] == val[4]) || (val[4] == val[5])) {
      payout = 1;
      return "One Pair payout 1";
    }
    //You couldn't win anything
    return "No match loser payout null!";
  }
  
  
  
}
