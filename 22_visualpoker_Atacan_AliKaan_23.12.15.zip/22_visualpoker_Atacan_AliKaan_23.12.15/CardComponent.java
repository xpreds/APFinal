//Ali Kaan Durany?ld?z and H�seyin Atacan Demir

import javax.swing.JComponent;
import javax.imageio.ImageIO;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.IOException;
import java.io.File;
import java.util.ArrayList;
import java.lang.Double;
import java.awt.event.*;


public class CardComponent extends JComponent implements MouseListener{
  Image image;
  boolean select1;
  boolean select2;
  boolean select3;
  boolean select4;
  boolean select5;
  final int width = 73;
  final int height = 98;
  int xPos;
  int yPos;
  int[] ii = new int[6];
  int[] j = new int[6];
  Hand hand;
  ArrayList<Double> selected = new ArrayList<Double>();
  public CardComponent(Hand h) {
    /*try {
     image = ImageIO.read(new File("poker.png"));
     System.out.println("File read");
     } catch (IOException e) {
     
     }*/
    image = Toolkit.getDefaultToolkit().getImage("poker.png");
    
    xPos = 100;
    yPos = 100;
    hand = h;
    addMouseListener(this);
  }
  
  public void paintComponent(Graphics g) {
    
    for(int i = 1; i <= 5; i++) {
      ii[i] = ((hand.hand[i]-1) / 13);//suit
      j[i] = (hand.hand[i]-1) % 13;//value
    }
    
    g.drawImage(image, xPos , yPos , xPos+width, yPos+height, j[1]*width , ii[1]*height, j[1]*width + width, ii[1]*height + height, null);
    g.drawImage(image, xPos+85 , yPos , xPos+85+width, yPos+height, j[2]*width , ii[2]*height, j[2]*width + width, ii[2]*height + height, null);
    g.drawImage(image, xPos+170 , yPos , xPos+170+width, yPos+height, j[3]*width , ii[3]*height, j[3]*width + width, ii[3]*height + height, null);
    g.drawImage(image, xPos+255 , yPos , xPos+255+width, yPos+height, j[4]*width , ii[4]*height, j[4]*width + width, ii[4]*height + height, null);
    g.drawImage(image, xPos+340 , yPos , xPos+340+width, yPos+height, j[5]*width , ii[5]*height, j[5]*width + width, ii[5]*height + height, null);
    
    repaint();
  }
  
  public ArrayList<Double> getSelected() {
    return selected;
  }
  
  public void mouseClicked(MouseEvent e) {
    
    if(e.getY() > 100 && e.getY() < 200) {
      if(e.getX() > 100 && e.getX() < 175) {
        if(select1) {
          select1 = false;
          selected.remove(1.0);
        } else {
          select1 = true;
          selected.add(1.0);
        }
      } else if(e.getX() > 185 && e.getX() < 260) {
        if(select2) {
          select2 = false;
          selected.remove(2.0);
        } else {
          select2 = true;
          selected.add(2.0);
        }
        
      } else if(e.getX() > 270 && e.getX() < 345) {
        if(select3) {
          select3 = false;
          selected.remove(3.0);
        } else {
          select3 = true;
          selected.add(3.0);
        }
        
      } else if(e.getX() > 355 && e.getX() < 430) {
        if(select4) {
          select4 = false;
          selected.remove(4.0);
        } else {
          select4 = true;
          selected.add(4.0);
        }
        
      } else if(e.getX() > 440 && e.getX() < 515) {
        if(select5) {
          select5 = false;
          selected.remove(5.0);
        } else {
          select5 = true;
          selected.add(5.0);
        }
        
      }
    }
    
  }
  
  public void mousePressed(MouseEvent e) {}
  public void mouseEntered(MouseEvent e) {}
  public void mouseReleased(MouseEvent e) {}
  public void mouseExited(MouseEvent e) {}
  
}
